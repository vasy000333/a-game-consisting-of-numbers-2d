import turtle
import os
import math
import colorsys
import winsound
import random
import tkinter as tk
from tkinter import messagebox
print("game version: alpha 0.0.0.b")
o = input("Write a level from 1 to 5 by entering the number of the level:").strip()

script_dir = os.path.dirname(os.path.abspath(__file__))
t3 = os.path.join(script_dir, o)

map = open(t3 + ".txt", "r", encoding="utf-8")
map = [list(row.strip()) for row in map]

screen = turtle.Screen()
screen.setup(width=1920, height=1080)
screen.setworldcoordinates(0, 0, 1920, 1080)
turtle.speed(0)
turtle.hideturtle()
turtle.penup()


npcs = []

npc_healths = []

for i, row in enumerate(map):
    for j, cell in enumerate(row):
        if cell == "3":
            py, px = i, j
        elif cell == "4":
            npcs.append([i, j])
            npc_healths.append(100)

player_angle = math.radians(90)
fov = math.radians(60)
screen_width = 1920
scale = 1
step_size = 0.1
max_distance = 100
hp = 100
hp4 = 100
ammo = 0
def draw_square(x, y, width, height, color_name, brightness=1.0):
    named_colors = {
        "red": (1, 0, 0),
        "green": (0, 1, 0),
        "blue": (0, 0, 1),
        "yellow": (1, 1, 0),
        "cyan": (0, 1, 1),
        "magenta": (1, 0, 1),
        "black": (0, 0, 0),
        "white": (1, 1, 1),
        "gray": (0.5, 0.5, 0.5),
    }

    rgb = named_colors.get(color_name.lower(), (0, 0, 0))

    h, l, s = colorsys.rgb_to_hls(*rgb)

    l = max(0, min(1, l * brightness))

    new_rgb = colorsys.hls_to_rgb(h, l, s)

    turtle.color(new_rgb)
    turtle.penup()
    turtle.goto(x, y)
    turtle.pendown()
    turtle.begin_fill()

    for _ in range(2):
        turtle.forward(width)
        turtle.left(90)
        turtle.forward(height)
        turtle.left(90)

    turtle.end_fill()

def line(x):
    ray_angle = player_angle - fov / 2 + (fov / screen_width) * x
    ray_x = px
    ray_y = py
    sin_a = math.sin(ray_angle)
    cos_a = math.cos(ray_angle)
    distance = 0
    hit = False
    
    while not hit and distance < max_distance:
        ray_x += cos_a * step_size
        ray_y += sin_a * step_size
        distance += step_size
        
        map_x = int(ray_x)
        map_y = int(ray_y)
        
        if map_y < len(map) and map_x < len(map[0]) and map[map_y][map_x] == "1" or map[map_y][map_x] == "6" or map[map_y][map_x] == "8" or map[map_y][map_x] == "7" or map[map_y][map_x] == "4" or map[map_y][map_x] == "5":
            hit = True
    
    wall_height = 1080 / (distance + 0.0001)
    if map[map_y][map_x] == "1":
        draw_square(x * scale, 540 - wall_height / 2, scale, wall_height,"blue",brightness=1.0)
    if map[map_y][map_x] == "8":
        draw_square(x * scale, 540 - wall_height / 2, scale, wall_height,"green",brightness=1.0)
    if map[map_y][map_x] == "6":
        draw_square(x * scale, 540 - wall_height / 2, scale, wall_height,"red",brightness=1.0)
    if map[map_y][map_x] == "7":
        draw_square(x * scale, 540 - wall_height / 2, scale, wall_height,"yellow",brightness=1.0)
    if map[map_y][map_x] == "4":
        draw_square(x * scale, 540 - wall_height / 2, scale, wall_height,"gray",brightness=1.0)
    if map[map_y][map_x] == "5":
        draw_square(x * scale, 540 - wall_height / 2, scale, wall_height,"cyan",brightness=1.0)

def lineu(x):
    ray_angle2 = player_angle - fov / 2 + (fov / screen_width) * x
    ray_x2, ray_y2 = px, py
    sin_a2, cos_a2 = math.sin(ray_angle2), math.cos(ray_angle2)
    distance2 = 0

    while distance2 < max_distance:
        ray_x2 += cos_a2 * step_size
        ray_y2 += sin_a2 * step_size
        distance2 += step_size

        map_x2, map_y2 = int(ray_x2), int(ray_y2)

        # проверка выхода за карту
        if not (0 <= map_y2 < len(map) and 0 <= map_x2 < len(map[0])):
            break  

        # попадание в NPC
        if map[map_y2][map_x2] == "4":
            if [map_y2, map_x2] in npcs:
                idx = npcs.index([map_y2, map_x2])
                npc_healths[idx] -= 50 # урон
            break # пуля дальше не летит
def cleanup_npcs():
    global npcs, npc_healths
    dead = []
    for i in range(len(npcs)):
        if npc_healths[i] <= 0:
            y, x = npcs[i]
            map[y][x] = " "
            dead.append(i)
    # удаляем по индексам с конца (чтобы не ломались списки)
    for i in reversed(dead):
        del npcs[i]
        del npc_healths[i]
        

turtle.tracer(0, 0)
def render():
    turtle.clear()
    for l in range(screen_width):
        line(l)
    print(f"number of lives: {hp}")
    print(f"number of bullets: {ammo}")
                 
    print(hp4)
    turtle.update()
def npc(direction, npc_index):
    global npcs, hp, npc_healths

    if npc_healths[npc_index] <= 0:
        return

    yn, xn = npcs[npc_index]

    if direction == 1:
        new_yn = yn + 1
        new_xn = xn
    elif direction == 2:
        new_yn = yn - 1
        new_xn = xn
    elif direction == 3:
        new_yn = yn
        new_xn = xn + 1
    elif direction == 4:
        new_yn = yn
        new_xn = xn - 1

    if map[new_yn][new_xn] != "1" and map[new_yn][new_xn] != "3" and map[new_yn][new_xn] != "4" and map[new_yn][new_xn] != "7":
        map[yn][xn] = " "
        npcs[npc_index] = [new_yn, new_xn]
        map[new_yn][new_xn] = "4"
# атакуем, если рядом с игроком
    if abs(yn - py) + abs(xn - px) == 1 and npc_healths[npc_index] > 0:
        hp -= 1
def show_error(message):
    root = tk.Tk()
    root.withdraw() # Скрываем главное окно Tk
    root.attributes('-topmost', 1) # Делаем поверх всех окон
    messagebox.showerror("Ошибка", message)
    root.destroy()

def m(nums: list[int]) -> int:
    if not nums:
        raise ValueError("List is empty")
    max_idx = 0
    for i in range(1, len(nums)):
        if nums[i] > nums[max_idx]:
            max_idx = i
    return max_idx


class Atom:
    def __init__(self):
        self.r = 0
        self.s = 0
        self.h = []
        self.con = []
        self.wisa = []


# список нейронов
atoms = []


def create_atom() -> int:
    """Создаёт новый нейрон и возвращает его индекс."""
    atoms.append(Atom())
    return len(atoms) - 1


def connect(a: int, b: int, w: float):
    """Соединяет нейрон a с нейроном b весом w (a → b)."""
    atoms[a].con.append(b)
    atoms[a].wisa.append(w)


def set_input(d, i):
    atoms[i].r = d
#    print(atoms[i].r)


def neiron(i):
    atoms[i].h = []
    p = 0
    for i2 in atoms[i].con:
        b = atoms[i].wisa[p]
        atoms[i].h.append(atoms[i2].r * b)
        p += 1
    yk = sum(atoms[i].h)
    if yk >= 10:
        atoms[i].r = 1
#        print(atoms[i].r)
    else:
        atoms[i].r = 0
#        print(atoms[i].r)
    if atoms[i].s != 0 and atoms[i].h:
        v = m(atoms[i].h)
        atoms[i].wisa[v] += atoms[i].s
        for i2 in atoms[i].con:
            atoms[i2].s = atoms[i].s


def output(i):
    atoms[i].h = []
    p = 0
    for i2 in atoms[i].con:
        b = atoms[i].wisa[p]
        atoms[i].h.append(atoms[i2].r * b)
        p += 1
    yk = sum(atoms[i].h)
    atoms[i].r = yk
#    print(atoms[i].r)
    if atoms[i].s != 0 and atoms[i].h:
        v = m(atoms[i].h)
        atoms[i].wisa[v] += atoms[i].s
        for i2 in atoms[i].con:
            atoms[i2].s = atoms[i].s
    return atoms[i].r
create_atom()
create_atom()
create_atom()
create_atom()
create_atom()
create_atom()
def n(a):
    yn, xn = npcs[a]
    set_input(xn,0)
    set_input(yn,1)
    set_input(px,2)
    set_input(py,3)
    r1 = output(4)
    r2 = output(5)
    connect(4,0,-1.0)
    connect(4,2,1.0)
    connect(5,1,-1.0)
    connect(5,3,1.0)
    if r1 < 0: npc(4, a)
    if r1 > 0: npc(3, a)
    if r2 < 0: npc(2, a)
    if r2 > 0: npc(1, a)


def a1():
    global py, px, player_angle, hp, ammo
    if map[py + 1][px] != "1":
        py += 1
        render()
def a2():
    global py, px, player_angle, hp, ammo
    if map[py - 1][px] != "1":
        py -= 1
        render()
def a3():
    global py, px, player_angle, hp, ammo
    if map[py][px - 1] != "1":
        px -= 1
        render()
def a4():
    global py, px, player_angle, hp, ammo
    if map[py][px + 1] != "1":
        px += 1
        render()
def a5():
    global py, px, player_angle, hp, ammo
    player_angle += math.radians(10)
    render()
def a6():
    global py, px, player_angle, hp, ammo
    player_angle -= math.radians(10)
    render()
def a7():
    global ammo
    if ammo > 0:
        center_ray = screen_width // 2
        lineu(center_ray) # стреляем только по центру экрана
        cleanup_npcs() # проверка смерти
        ammo -= 1
        o2 = "357_fire2.wav"
        t2 = os.path.join(script_dir, o2)
        winsound.PlaySound(t2, winsound.SND_FILENAME | winsound.SND_ASYNC)
screen.onkeypress(a3, 'a')
screen.onkeypress(a4, 'd')
screen.onkeypress(a2, 's')
screen.onkeypress(a1, 'w')
screen.onkeypress(a5, 'l')
screen.onkeypress(a6, 'k')
screen.onkeypress(a7, 'o')
screen.listen()

render()
def dvi():
    global py, px, player_angle, hp, ammo

    if map[py][px] == "6":
        o2 = "Half-LifeDamage.wav"
        t2 = os.path.join(script_dir, o2)
        winsound.PlaySound(t2, winsound.SND_FILENAME | winsound.SND_ASYNC)
        hp -= 90
        map[py][px] = " "

    if map[py][px] == "8":
        o2 = "smallmedkit1.wav"
        t2 = os.path.join(script_dir, o2)
        winsound.PlaySound(t2, winsound.SND_FILENAME | winsound.SND_ASYNC)
        hp += 10
        map[py][px] = " "

    if map[py][px] == "7":
        o2 = "RobloxVictory.wav"
        t2 = os.path.join(script_dir, o2)
        winsound.PlaySound(t2, winsound.SND_FILENAME | winsound.SND_ASYNC)
        show_error("you win!")
        map[py][px] = " "
        return

    if map[py][px] == "5":
        o2 = "ammo_pickup.wav"
        t2 = os.path.join(script_dir, o2)
        winsound.PlaySound(t2, winsound.SND_FILENAME | winsound.SND_ASYNC)
        ammo += 10
        map[py][px] = " "

    if hp <= 0:
        show_error("game over!")
        return

    for i in range(len(npcs)):
        n(i)

    screen.ontimer(dvi, 100) # повтор каждые 100 мс

dvi()
turtle.done()