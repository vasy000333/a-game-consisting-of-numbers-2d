import math
import turtle

# ----- Настройки экрана -----
screen_width = 800
screen_height = 600
screen = turtle.Screen()
screen.setup(width=screen_width, height=screen_height)
screen.setworldcoordinates(0, 0, screen_width, screen_height)

turtle.speed(0)
turtle.hideturtle()
turtle.penup()
turtle.tracer(0, 0)

# ----- Камера -----
xp, yp, zp = 2, 2, 5 # позиция камеры
player_angle = 0 # yaw
cam_pitch = 0 # pitch (вверх/вниз)
cam_dx, cam_dy, cam_dz = 0, 0, -1 # направление взгляда
move_speed = 0.2
rot_speed = math.radians(10)

def update_cam_dir():
    global cam_dx, cam_dy, cam_dz
    cam_dx = math.sin(player_angle) * math.cos(cam_pitch)
    cam_dy = math.sin(cam_pitch)
    cam_dz = -math.cos(player_angle) * math.cos(cam_pitch)

update_cam_dir()

# ----- Класс атомов -----
class Atom:
    def __init__(self, x=0, y=0, z=0):
        self.x = x
        self.y = y
        self.z = z
        self.con = []

    def try_join(self, other):
        if other not in self.con and other:
            dx = abs(self.x - other.x)
            dy = abs(self.y - other.y)
            dz = abs(self.z - other.z)
            if dx + dy + dz == 1:
                self.con.append(other)
                other.con.append(self)
class col:
    def __init__(self,y2,y1,x2,x1,z2,z1):
        self.y2 = y2
        self.y1 = y1
        self.x2 = x2
        self.x1 = x1
        self.z2 = z2
        self.z1 = z1

atoms = []
ob = []
def create(x, y, z):
    atoms.append(Atom(x, y, z))
def createob(y2,y1,x2,x1,z2,z1):
    ob.append(col(y2,y1,x2,x1,z2,z1))
def colision(x,y,z):
    for b in ob:
        if b.y2 < y < b.y1 and b.x2 < x < b.x1 and b.z2 < z < b.z1:
            return False
        else:
            return True

# ----- Рисование -----
def draw_point(screen_x, screen_y):
    turtle.penup()
    turtle.goto(screen_x, screen_y)
    turtle.pendown()
    turtle.dot(8, "black")

bond_drawer = turtle.Turtle()
bond_drawer.hideturtle()
bond_drawer.color("gray")
bond_drawer.penup()

def draw_bonds():
    bond_drawer.clear()
    for atom in atoms:
        for other in atom.con:
            if id(atom) < id(other):
                p1 = project_point(atom)
                p2 = project_point(other)
                if p1 and p2:
                    bond_drawer.goto(p1)
                    bond_drawer.pendown()
                    bond_drawer.goto(p2)
                    bond_drawer.penup()

# ----- Вспомогательные функции -----
def dot(a, b):
    return a[0]*b[0] + a[1]*b[1] + a[2]*b[2]

def cross(a, b):
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])

def normalize(vx, vy, vz):
    mag = math.sqrt(vx**2 + vy**2 + vz**2)
    if mag == 0:
        return (0, 0, 0)
    return (vx/mag, vy/mag, vz/mag)

# ----- Проекция -----
def project_point(atom):
    dx = atom.x - xp
    dy = atom.y - yp
    dz = atom.z - zp

    fwd = normalize(cam_dx, cam_dy, cam_dz)
    right = normalize(*cross((0,1,0), fwd))
    up = cross(fwd, right)

    x1 = dot((dx, dy, dz), right)
    y1 = dot((dx, dy, dz), up)
    z1 = dot((dx, dy, dz), fwd)

    if z1 <= 0:
        return None

    fov = 500
    screen_x = screen_width/2 + (x1 / z1) * fov
    screen_y = screen_height/2 - (y1 / z1) * fov
    return (screen_x, screen_y)

# ----- Рендер -----
def render():
    turtle.clear()
    for atom in atoms:
        for other in atoms:
            if atom != other:
                atom.try_join(other)
    for atom in atoms:
        pos = project_point(atom)
        if pos:
            draw_point(*pos)
    draw_bonds()
    turtle.update()

# ----- Создание куба 2x2x2 -----
createob(0,1,0,1,0,1)
create(0,0,0)
create(1,0,0)
create(0,1,0)
create(1,1,0)
create(0,0,1)
create(1,0,1)
create(0,1,1)
create(1,1,1)
create(4,1,1)

# ----- Движение камеры -----
def move_forward():
    global xp, yp, zp
    m1 = xp + cam_dx * move_speed
    m2 = yp + cam_dy * move_speed
    m3 = zp + cam_dz * move_speed
    h = colision(m1,m2,m3)
    if h:
        xp += cam_dx * move_speed
        yp += cam_dy * move_speed
        zp += cam_dz * move_speed
    render()

def move_backward():
    global xp, yp, zp
    m4 = xp - cam_dx * move_speed
    m5 = yp - cam_dy * move_speed
    m6 = zp - cam_dz * move_speed
    h2 = colision(m4,m5,m6)
    if h2:
        xp -= cam_dx * move_speed
        yp -= cam_dy * move_speed
        zp -= cam_dz * move_speed
    render()

def move_left():
    global xp, zp
    right = normalize(*cross((0,1,0), (cam_dx, cam_dy, cam_dz)))
    i1 = xp - right[0] * move_speed
    i2 = zp - right[2] * move_speed
    h3 = colision(i1,yp,i2)
    if h3:
        xp -= right[0] * move_speed
        zp -= right[2] * move_speed

    render()

def move_right():
    global xp, zp
    right = normalize(*cross((0,1,0), (cam_dx, cam_dy, cam_dz)))
    i3 = xp + right[0] * move_speed
    i4 = zp + right[2] * move_speed
    h4 = colision(i3,yp,i4)
    if h4:
        xp += right[0] * move_speed
        zp += right[2] * move_speed

    render()

# ----- Вращение камеры -----
def turn_left():
    global player_angle
    player_angle -= rot_speed
    update_cam_dir()
    render()

def turn_right():
    global player_angle
    player_angle += rot_speed
    update_cam_dir()
    render()

def look_up():
    global cam_pitch
    cam_pitch += rot_speed
    if cam_pitch > math.pi/2:
        cam_pitch = math.pi/2
    update_cam_dir()
    render()

def look_down():
    global cam_pitch
    cam_pitch -= rot_speed
    if cam_pitch < -math.pi/2:
        cam_pitch = -math.pi/2
    update_cam_dir()
    render()

# ----- Клавиши -----
screen.onkeypress(move_forward, 'w')
screen.onkeypress(move_backward, 's')
screen.onkeypress(move_left, 'a')
screen.onkeypress(move_right, 'd')
screen.onkeypress(turn_left, 'l')
screen.onkeypress(turn_right, 'j')
screen.onkeypress(look_up, 'i')
screen.onkeypress(look_down, 'k')
screen.listen()

render()
turtle.done()