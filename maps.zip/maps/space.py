import os
import time
import threading
import random
import winsound
print("game version: alpha 0.0.0")
print("if you don't know how to play, check out the file called Instructions.txt")
o = input("write a level from 1 to 5 by entering the number of the level:").strip()

script_dir = os.path.dirname(os.path.abspath(__file__))
t = os.path.join(script_dir, o)

map = open(t + ".txt", "r", encoding="utf-8")
map = [list(row.strip()) for row in map]
w = False
i = 0
yp = 0
xp = 0
hpnpc = 100

npcs = []

npc_healths = []

for i, row in enumerate(map):
    for j, cell in enumerate(row):
        if cell == "3":
            yp, xp = i, j
        elif cell == "4":
            npcs.append([i, j])
            npc_healths.append(100)

hp = 100
potron = 0
radius = 7

def draw():
    print("\033c", end="")

    try:
        height = len(map)
        width = len(map[0])
    except IndexError:
        print("Ошибка: Карта не определена.")
        return

    start_y = max(0, yp - radius)
    end_y = min(height, yp + radius + 1)
    start_x = max(0, xp - radius)
    end_x = min(width, xp + radius + 1)

    for y in range(start_y, end_y):
        row = ""
        for x in range(start_x, end_x):
            if 0 <= y < height and 0 <= x < width:
                row += map[y][x]
            else:
                row += " "
        print(row)

    print(f"number of lives: {hp}")
    print(f"number of bullets: {potron}")

def dvi(a, b, xp, yp):
    if map[a][b] != "1":
        map[yp][xp] = " "
        xp, yp = b, a
        map[yp][xp] = "3"
        draw()
    return xp, yp

def npc(direction, npc_index):
    global npcs, hp, npc_healths

    if npc_healths[npc_index] <= 0:
        return

    yn, xn = npcs[npc_index]

    if direction == 1:
        new_yn = yn + 1
        new_xn = xn
    elif direction == 2:
        new_yn = yn - 1
        new_xn = xn
    elif direction == 3:
        new_yn = yn
        new_xn = xn + 1
    elif direction == 4:
        new_yn = yn
        new_xn = xn - 1

    if map[new_yn][new_xn] != "1" and map[new_yn][new_xn] != "3" and map[new_yn][new_xn] != "4" and map[new_yn][new_xn] != "7":
        map[yn][xn] = " "
        npcs[npc_index] = [new_yn, new_xn]
        map[new_yn][new_xn] = "4"

    if abs(new_yn - yp) + abs(new_xn - xp) == 1 and npc_healths[npc_index] >= 0:
        hp -= 10

def n(a):
    r1 = (xn * -1) + (xp * 1)
    r2 = (yn * -1) + (yp * 1)
    if r1 != 0 and r2 != 0:
        x = random.randint(0, 1)
        if x == 1:
            if r1 < 0: npc(4, a)
            if r1 > 0: npc(3, a)
        else:
            if r2 < 0: npc(2, a)
            if r2 > 0: npc(1, a)
    else:
        if r1 < 0: npc(4, a)
        if r1 > 0: npc(3, a)
        if r2 < 0: npc(2, a)
        if r2 > 0: npc(1, a)

draw()

while 3 == 3:
    if hp <= 0:
        os.system("cls")
        print("game over!")
        input("press the enter button to exit")
        break

    d = input("move(w,s,d,a):")

    newxp, newyp = xp, yp

    if d == "s":
        newyp += 1
    if d == "w":
        newyp -= 1
    if d == "a":
        newxp -= 1
    if d == "d":
        newxp += 1

    if map[newyp][newxp] == "7":
        os.system("cls")
        o2 = "RobloxVictory.wav"
        script_dir1 = os.path.dirname(os.path.abspath(__file__))
        t2 = os.path.join(script_dir, o2)

        winsound.PlaySound(t2, winsound.SND_FILENAME|winsound.SND_ASYNC)
        print("you win!")
        input("press the enter button to exit")
        break
    if map[newyp][newxp] == "4":
        npc_index = npcs.index([newyp, newxp])
        if npc_healths[npc_index] > 0:
            hp -= 3
    if map[newyp][newxp] == "6":
        hp -= 90
        o1 = "Half-LifeDamage.wav"
        script_dir1 = os.path.dirname(os.path.abspath(__file__))
        t1 = os.path.join(script_dir, o1)

        winsound.PlaySound(t1, winsound.SND_FILENAME|winsound.SND_ASYNC)
    if map[newyp][newxp] == "5":

        o1 = "ammo_pickup.wav"
        script_dir1 = os.path.dirname(os.path.abspath(__file__))
        t1 = os.path.join(script_dir, o1)

        winsound.PlaySound(t1, winsound.SND_FILENAME|winsound.SND_ASYNC)
        w = True
        potron += 3

    if map[newyp][newxp] == "4" and w == True:
         for i, (yn, xn) in enumerate(npcs):
            if yn == newyp and xn == newxp:
                npc_healths[i] -= 100
                potron -= 1
                o3 = "villager.wav"
                script_dir1 = os.path.dirname(os.path.abspath(__file__))
                t3 = os.path.join(script_dir, o3)
                winsound.PlaySound(t3, winsound.SND_FILENAME|winsound.SND_ASYNC)

    if map[newyp][newxp] == "8":
        hp += 10

        o2 = "smallmedkit1.wav"
        script_dir1 = os.path.dirname(os.path.abspath(__file__))
        t2 = os.path.join(script_dir, o2)

        winsound.PlaySound(t2, winsound.SND_FILENAME|winsound.SND_ASYNC)
    if potron <= 0:
        w = False 

    xp, yp = dvi(newyp, newxp, xp, yp)

    for i in range(len(npcs)):
        yn, xn = npcs[i]
        n(i)